from django.apps import AppConfig


class CollegesystemConfig(AppConfig):
    name = 'CollegeSystem'
